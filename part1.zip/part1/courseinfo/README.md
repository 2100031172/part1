# Course information

Simple web applicaton for understanding the core concepts of React

## Start the application

To start an application, do the following :

```bash
# Install dependancies
$ yarn install
# Start the application
$ yarn start
```

You can then access the app on : [http://localhost:3000/](http://localhost:3000/)